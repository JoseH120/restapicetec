-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.4.32-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para restapi
DROP DATABASE IF EXISTS `restapi`;
CREATE DATABASE IF NOT EXISTS `restapi` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `restapi`;

-- Volcando estructura para tabla restapi.blog
DROP TABLE IF EXISTS `blog`;
CREATE TABLE IF NOT EXISTS `blog` (
  `post_id` int(11) NOT NULL AUTO_INCREMENT,
  `post_title` varchar(255) NOT NULL,
  `post_description` text NOT NULL,
  `post_created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `post_featured_image` varchar(255) NOT NULL,
  PRIMARY KEY (`post_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.blog: ~5 rows (aproximadamente)
INSERT INTO `blog` (`post_id`, `post_title`, `post_description`, `post_created_at`, `post_featured_image`) VALUES
	(1, 'Post Title 1', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Quod, praesentium enim. Vel cum dolore quibusdam est corrupti delectus illo minima optio, perferendis minus. Sunt possimus tenetur quisquam nihil quaerat, recusandae doloremque? Culpa ad facilis corporis, sint dolores optio repellendus repellat molestiae temporibus dolorem itaque repudiandae, suscipit ducimus sapiente esse rem vitae totam sequi recusandae nobis maiores natus. Enim nisi possimus quas tempora eius in quisquam ullam sequi quaerat eos at sit, exercitationem sed maxime! Culpa ratione beatae saepe sapiente soluta reiciendis omnis cumque. Ullam facilis error nisi expedita sed provident laborum aliquid, numquam animi, laudantium aliquam illo reiciendis debitis praesentium.', '2024-07-13 20:02:49', ''),
	(2, 'Post Title2', 'Lorem ipsum dolor, sit amet consectetur adipisicing elit. Neque vel laboriosam animi numquam vero illum eum, voluptates similique dolorum, libero maxime iure ratione odit? Corporis tempora repellat quaerat numquam a, labore pariatur, iure vero ipsam esse, dolor quae aspernatur dicta?', '2024-07-13 20:02:49', ''),
	(3, 'Where does it come from?', 'Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of "de Finibus Bonorum et Malorum" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, "Lorem ipsum dolor sit amet..", comes from a line in section 1.10.32.', '2024-07-13 20:03:59', ''),
	(4, 'Why do we use it?', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '2024-07-13 20:03:59', '72-200x300.jpg'),
	(5, 'here is the title for this post', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Phasellus ac ipsum ante. Suspendisse vitae ante ut lorem fringilla hendrerit eget vel dolor. Nulla congue euismod nunc pretium hendrerit. Sed ac justo eget est ullamcorper vehicula. Nam mollis libero fermentum tortor sodales consequat. Sed at viverra justo, non suscipit ex. Sed imperdiet cursus felis a dignissim. Nunc tempus ligula sit amet tristique commodo. Nullam scelerisque, elit in venenatis iaculis, libero mauris sollicitudin ligula, id malesuada sem arcu in ante. Vestibulum dui mi, mollis ac blandit vitae, tincidunt quis libero. Praesent massa neque, porttitor vel massa non, aliquam sollicitudin urna. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.', '2024-07-20 04:54:37', '72-200x300_1.jpg');

-- Volcando estructura para tabla restapi.oauth_access_tokens
DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `access_token` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(80) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `scope` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`access_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.oauth_access_tokens: ~9 rows (aproximadamente)
INSERT INTO `oauth_access_tokens` (`access_token`, `client_id`, `user_id`, `expires`, `scope`) VALUES
	('1ddd9d3b3e8f93d08f9dfd48e6eec486bfeb1d20', 'testclient', '1', '2024-07-18 10:11:57', 'app'),
	('2fae1f4f5c870bd71d472636adc973bca58a69ca', 'testclient', '1', '2024-07-22 19:14:38', 'app'),
	('40c66d9a170f9f2b24469fceefca69a71b6d220b', 'testclient', '2', '2024-07-20 17:45:57', 'app'),
	('6b5e003a7a7472fabc4a1637339c41ec041f88ee', 'testclient', 'alexlancer', '2024-07-17 19:22:16', 'app'),
	('92fe467e698addd647a633bf786c63fbb53cdd34', 'testclient', '1', '2024-07-22 02:15:11', 'app'),
	('9aa71b0f79114175f4ca6cc4fbf304e37c440646', 'testclient', '1', '2024-07-20 17:52:47', 'app'),
	('a4216968fdf3c995e33cef037f614d0db458b4cc', 'testclient', '2', '2024-07-22 19:15:08', 'app'),
	('ce2f3e2eb8f9cab3631adf20dc51ca8a08d09978', 'testclient', '1', '2024-07-19 07:59:37', 'app'),
	('e595bf0986fdcddb6d7ab1495498fb14ff20f71b', 'testclient', '1', '2024-07-18 10:12:27', 'app');

-- Volcando estructura para tabla restapi.oauth_authorization_codes
DROP TABLE IF EXISTS `oauth_authorization_codes`;
CREATE TABLE IF NOT EXISTS `oauth_authorization_codes` (
  `authorization_code` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(80) DEFAULT NULL,
  `redirect_uri` varchar(2000) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `scope` varchar(4000) DEFAULT NULL,
  `id_token` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`authorization_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.oauth_authorization_codes: ~0 rows (aproximadamente)

-- Volcando estructura para tabla restapi.oauth_clients
DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `client_id` varchar(80) NOT NULL,
  `client_secret` varchar(80) DEFAULT NULL,
  `redirect_uri` varchar(2000) DEFAULT NULL,
  `grant_types` varchar(80) DEFAULT NULL,
  `scope` varchar(4000) DEFAULT NULL,
  `user_id` varchar(80) DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.oauth_clients: ~1 rows (aproximadamente)
INSERT INTO `oauth_clients` (`client_id`, `client_secret`, `redirect_uri`, `grant_types`, `scope`, `user_id`) VALUES
	('testclient', 'testsecret', NULL, 'password', 'app', NULL);

-- Volcando estructura para tabla restapi.oauth_jwt
DROP TABLE IF EXISTS `oauth_jwt`;
CREATE TABLE IF NOT EXISTS `oauth_jwt` (
  `client_id` varchar(80) NOT NULL,
  `subject` varchar(80) DEFAULT NULL,
  `public_key` varchar(2000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.oauth_jwt: ~0 rows (aproximadamente)

-- Volcando estructura para tabla restapi.oauth_refresh_tokens
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `refresh_token` varchar(40) NOT NULL,
  `client_id` varchar(80) NOT NULL,
  `user_id` varchar(80) DEFAULT NULL,
  `expires` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `scope` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`refresh_token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.oauth_refresh_tokens: ~9 rows (aproximadamente)
INSERT INTO `oauth_refresh_tokens` (`refresh_token`, `client_id`, `user_id`, `expires`, `scope`) VALUES
	('06ba9fe76eb91be1be828f5eaa6c1864ed0fd909', 'testclient', '2', '2024-08-05 18:15:08', 'app'),
	('0a03886c2c643eaaf46cf560e3dbb460b1fa747b', 'testclient', '1', '2024-08-01 09:11:57', 'app'),
	('4a0f0f1e522fabbfc0c4c0540433dc5115bdee74', 'testclient', '1', '2024-08-01 09:12:27', 'app'),
	('670a07b41e1d3aa5f07e98e37508f5c5acb1b27b', 'testclient', '1', '2024-08-03 16:52:47', 'app'),
	('7196b8c49fee21b45c631a3429d862991fdd3334', 'testclient', '2', '2024-08-03 16:45:57', 'app'),
	('805353d02be9b0dd7d964c5cf30de1288923f96d', 'testclient', '1', '2024-08-05 01:15:11', 'app'),
	('c90f1a81e53081514c49f8843abbb2ceb8a0234a', 'testclient', '1', '2024-08-05 18:14:38', 'app'),
	('e5a2195b22e7c450530ef9c4afdda040d113a0da', 'testclient', 'alexlancer', '2024-07-31 18:22:16', 'app'),
	('f048767b5df3989cdb5427c78027d6051a09216e', 'testclient', '1', '2024-08-02 06:59:37', 'app');

-- Volcando estructura para tabla restapi.oauth_scopes
DROP TABLE IF EXISTS `oauth_scopes`;
CREATE TABLE IF NOT EXISTS `oauth_scopes` (
  `scope` varchar(80) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`scope`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.oauth_scopes: ~0 rows (aproximadamente)

-- Volcando estructura para tabla restapi.oauth_users
DROP TABLE IF EXISTS `oauth_users`;
CREATE TABLE IF NOT EXISTS `oauth_users` (
  `username` varchar(80) NOT NULL,
  `password` varchar(80) DEFAULT NULL,
  `first_name` varchar(80) DEFAULT NULL,
  `last_name` varchar(80) DEFAULT NULL,
  `email` varchar(80) DEFAULT NULL,
  `email_verified` tinyint(1) DEFAULT NULL,
  `scope` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.oauth_users: ~1 rows (aproximadamente)
INSERT INTO `oauth_users` (`username`, `password`, `first_name`, `last_name`, `email`, `email_verified`, `scope`) VALUES
	('alexlancer', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'Alex', 'Lancer', 'test@alexlancer.com', 1, 'app');

-- Volcando estructura para tabla restapi.users
DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `scope` varchar(20) NOT NULL DEFAULT 'app',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Volcando datos para la tabla restapi.users: ~2 rows (aproximadamente)
INSERT INTO `users` (`id`, `firstname`, `lastname`, `email`, `password`, `scope`, `created_at`) VALUES
	(1, 'Alex', 'Lancer', 'test@alexlancer.com', '$2y$10$USgXat4p4i2R1s3M6JVby.g0ogRDqnetPoiaIUx1OkcQOtTWn2WoO', 'app', '2024-07-17 21:08:03'),
	(2, 'Jose', 'Hernandez', 'jose@gmail.com', '$2y$10$l3DT0dHZ3LUkE3TuA2M.6uvs7uUGufQ1kjbhI6pbJF0qxyn4Tbg72', 'app', '2024-07-20 04:44:46');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
